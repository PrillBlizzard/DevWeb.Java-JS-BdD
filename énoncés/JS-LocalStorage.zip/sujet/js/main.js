import { ApplicationMemory} from "./application/application-memory.js"

window.addEventListener("load", () => {
    const app = new ApplicationMemory();
})