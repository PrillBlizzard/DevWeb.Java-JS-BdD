export class Observer
{
    notify()
    {
        throw "Observer::notify - This function has to be override.";
    }
}